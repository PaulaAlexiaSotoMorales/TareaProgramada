
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julio
 */
public class Productor extends Thread{
    
    private Buffer buffer; 
    private final String letras = "abcdefghijklmnopqrstuvwxyz";
    
    public Productor (Buffer buf){
        
        this.buffer = buf; 
    }
    
    public void RUN(){
        
        
        while(true){
            try {
                char con = letras.charAt((int) (Math.random() * letras.length()));
                buffer.pruductor(con);
                System.out.println("La letra es "+con + " del buffer."); 
                sleep ((int) (Math.random() * 4000));
            } catch (InterruptedException ex) {
                Logger.getLogger(Productor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}